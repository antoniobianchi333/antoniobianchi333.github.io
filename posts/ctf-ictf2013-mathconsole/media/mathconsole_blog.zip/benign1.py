#! /usr/bin/env python

import random
import re
import hashlib
import base64
import sys
import binascii
from socket import socket
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5 
from Crypto.Hash import SHA
from ecdsa import SigningKey



private_key_rsa_pem = '''
-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEAmomIElIbg8ZEXQ6S3gMv8LYED0YrqvRpddUwSgpMJNdOOHK/
l9TeRlkKq9AXqF9rvvotd4mqkfZxvBMpiRGcOfwl88eLMBLhmYa367Cfx5PAISkK
rgGDqZo2m+5DvzmEhlh6fU8azlL+alutqrg+m5kzZ5RQxJZquBsH87J/TKvmHIG0
A3vXN7RI8mfcBc1sWzFik0KdpqpPd1gc0NmCUAP6uNUtQInPhLr3Da0mI78mm6ff
tqHp8Z4EtgH47VWxprDiCr0NxxefBgZFIfCxNa0ErwwzKDsPYi3Mx6VWBz4/kt8F
xLvomvqixQIHlqZzsEkPsHURfLosLDw8cNAjdwIDAQABAoIBAH7/e0WjGF2IuHHJ
IkU1VVZ6Hof24LgTN//P/Wk7YSv9jJizJGTAWRJy5mQgFPEXydIegvLzvatKXllz
XfT49expHT9jwyz0t1WV8tvMQOKgt4oI0nABapQc2bf3bNFfkVtepvsH4T2h0tbR
FL1xwHHayvXaWy3Td0xpWnWZQShd7J56ln4NqFnZmS1/cx9mYkvFl2Vg4JcuolBD
UUplMGdVuadyOQhjuK9g0oLgKRQqiEgz3fJ/o6y8vdDidS2cBeXiRiMrzAiVJkuI
HneYjtmT1f+DaENSv/QMdyWDcmDw/yeUWnNzEcg/c9UUaeb3dv/DwuEISPEqNWo6
Yi/eSMECgYEAuprqAgUkx9UqjB/M6DjmwrQOSEBhSIulIAJOxjyZnRpkpbJ+7WnB
p+zRqssLdLktUbkBPII/oKg1Cx4wq7NiM4tN2NbXz57OX2pNvaF5nLQlutaqv3LL
ZMsAPrvKGew4LcP/t+MBUuRveNLamlJcdEF2JYgM+EiE1I+kxYFMfgcCgYEA1AG0
pbyS005pvk9bGCicxTFB3qgOlVwMWwy0YYNOiBJtxShaB9o4OLC5vzurb/jdT5ds
6dh1TtPGX55MuVffMGk0wiAaceFctqx4IeXdrAKVzo8M7lHhKH2VorkXFB6VBJ6v
r6W3etdrsAD2xJsRNMvjgor+KIpeoElh5MNE0xECgYBt1SyTD8/8Rr2KSFVlAcjh
JPWbFTmtZ3RDiNgw2g5YZ+aBmLQYrTysyDkIXAZcJ3pDNa9CnC8zMo42AwkGpsjQ
KdgiHyJbM8+oXXtweBCKaYYjmKJbmQeaRdnZEtL7uwu99DUZWOW4kngCF6lPV9bP
HpCZuqBXqudz7TBAh8AsFQKBgQCdYcLEAlAQ0zYGlAxwy71NWbqnWqSw1gtKEA1c
EkjbFKsuYD0tdR6lXvQU9WvYDKvl6OhuVEUJRocN9orIUGYcHw2OSpy3C3BzH2dy
6px7k9O36lPUGy6Fi2zoxnROeEFxk4eiYefqJj8IAj8uRlsokW8MOrhgSg/i93bX
hunxsQKBgADki5uscM/MkKQECWnnMl7qBlhFWTtEVfDpq5XCNqNadCxj20jjm0jZ
ofbFxFLlX9j+vKt9QJMK2kz3d9mew7WyC9nJEVvGPUyxcz0UYae8xIoJcRnOkZtO
4l/xJGLDPCW1cOVeapVWwMSn5/6TdP+kAXHjaR+YhPWdHgzzQHpL
-----END RSA PRIVATE KEY-----
'''
private_key_rsa = RSA.importKey(private_key_rsa_pem.strip())
old_data =''
max_num = 4000

class Benign(): #this will just interact with the math functionalities using l1 or l2

    def wait_for_regex(self, regex, pdata=True):
        global old_data
        compiled_regex = re.compile(regex)
        while True:
            data = self.sock_file.readline()
            if(pdata):
                print "->" + repr(data) + "<-"
            if(len(data)==0):
                raise Exception("Connection closed last received message: " + old_data
                    + " waiting for:" + regex)
            elif (compiled_regex.match(data)):
                break;
            old_data = data

    def sha1(self,content):
        sha1_hash = hashlib.sha1()
        sha1_hash.update(content)
        hash = sha1_hash.digest()
        return hash
                
    def execute(self, ip, port, flag_id='', token=''):
        error = 0
        error_msg = ''
        connected = False
        try:
            s = socket()
            s.connect((ip, port))
            self.sock = s
            self.sock_file = s.makefile()
            connected = True            

            self.do_benign(s)
        except BaseException, e:
            if ((not connected)):
                error = -42
            else:
                error = 42
            error_msg = str(type(e)) + ":" + str(e)

        self.flag_id = ''
        self.token = ''
        self.error = error
        self.error_msg = error_msg

    def result(self):
        return {'FLAG_ID' : self.flag_id,
                'TOKEN' : self.token,
                'ERROR' : self.error,
                'ERROR_MSG' : self.error_msg,
               }

    def send_msg(self, data):
        self.sock.sendall(data + "\n")             
        
    def recv_msg(self):
        data = self.sock_file.readline()
        if(len(data)==0):
            raise Exception("Exit")
        return data.strip()
               
    def do_benign(self,s):
        random.seed()
        
        methods = ["l1","l2"]
        commands = ["sum","multiply","mod"]
        n1 = str(random.randint(1,max_num))
        n2 = str(random.randint(1,max_num))
        
        command = random.choice(commands)
        
        if(command == "multiply"):
            method = "l1"
        else:
            method = random.choice(methods)
            
        full_command = command + "|" + n1 + "|" + n2
        
        if(method == "l1"):
            print "l1"
            hash = self.sha1(full_command)
            cert = "X"*(256-len(hash)) + hash
        else:
            print "l2"
            signer = PKCS1_v1_5.new(private_key_rsa)
            digest = SHA.new() 
            digest.update(full_command)
            cert = signer.sign(digest)
        
        print full_command
        self.wait_for_regex("^what do you want to do?")
        self.send_msg(full_command)
        self.wait_for_regex("^give me the certificate!")
        self.send_msg(base64.b64encode(cert))
        self.wait_for_regex("^Result")
        nstr = self.recv_msg()
        print nstr
        try:
            n = int(nstr)
        except ValueError:
            Exception("Invalid number returned")
        self.wait_for_regex("^Bye")
        
        
        
if __name__ == "__main__":
    b = Benign()
    b.execute("127.0.0.1",9898)
    print repr(b.result())
        

